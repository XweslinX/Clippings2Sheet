import os
import csv
import re
from collections import defaultdict

def read_clippings_file(file_path):
    """
    Read file content with utf-8-sig encoding, automatically handling the UTF-8 BOM marker.
    """
    if not os.path.exists(file_path):
        print(f"Error: File not found {file_path}")
        return None

    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            # Return all lines for subsequent state machine processing
            return f.readlines()
    except Exception as e:
        print(f"Error reading file: {e}")
        return None

def cleanup_output_file(file_path):
    """
    At program startup, if My Clippings.csv already exists in the current directory, delete it.
    """
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        print(f"Failed to clean up old file: {e}")

def parse_clippings(lines):
    """
    Use a state machine to parse text lines, converting My Clippings.txt into a raw entry list.
    """
    entries = []
    state = "IDLE" # Initial state: looking for book title
    current_entry = {}

    for line in lines:
        clean_line = line.strip()

        # Hit separator, end current entry, reset state
        if clean_line == "==========":
            if current_entry:
                entries.append(current_entry)
            current_entry = {}
            state = "IDLE"
            continue

        # State [IDLE]: Looking for book title (non-empty line is the book title)
        if state == "IDLE" and clean_line:
            current_entry['book'] = clean_line
            state = "METADATA"

        # State [METADATA]: Parse metadata line (starts with '- Your')
        elif state == "METADATA" and clean_line.startswith("- Your"):
            # 1. Extract type: Highlight, Note, or Bookmark
            if "Highlight" in clean_line:
                entry_type = "Highlight"
            elif "Note" in clean_line:
                entry_type = "Note"
            else:
                entry_type = "Bookmark"
            current_entry['type'] = entry_type

            # 2. Extract Location: match number or range (e.g. 123 or 123-124)
            loc_match = re.search(r"Location (\d+(?:-\d+)?)", clean_line)
            current_entry['location'] = loc_match.group(1) if loc_match else "Unknown"

            # 3. Extract Page: match 'page ' followed by a number
            page_match = re.search(r"page (\d+)", clean_line)
            current_entry['page'] = page_match.group(1) if page_match else ""

            # 4. Extract date (Added on ...): match all content after 'Added on '
            time_match = re.search(r"Added on (.*)", clean_line)
            current_entry['date'] = time_match.group(1) if time_match else ""

            state = "CONTENT"

        # State [CONTENT]: Read body content (until separator is encountered)
        elif state == "CONTENT":
            if not clean_line and not current_entry.get('content'):
                continue

            if 'content' not in current_entry:
                current_entry['content'] = line.rstrip('\n')
            else:
                current_entry['content'] += "\n" + line.rstrip('\n')

    if current_entry:
        entries.append(current_entry)

    return entries

def get_loc_range(loc_str):
    """
    Convert location string to numeric range (start, end).
    E.g.: "200-220" -> (200, 220), "210" -> (210, 210).
    """
    if not loc_str or loc_str == "Unknown":
        return (None, None)

    parts = loc_str.split('-')
    try:
        start = int(parts[0])
        end = int(parts[1]) if len(parts) > 1 else start
        return (start, end)
    except ValueError:
        return (None, None)

def merge_entries(raw_entries):
    """
    Merge highlights (Highlight) and user notes (Note) into the same row based on (book title, location range).
    Highlights with the same location conflict each keep their own row, not merged.
    """
    merged = {} # key: (book, start, end, seq)
    notes_pending = []
    collision_counter = {}

    for entry in raw_entries:
        if entry['type'] in ["Highlight", "Bookmark"]:
            book = entry.get('book', 'Unknown')
            loc_str = entry.get('location', 'Unknown')
            start, end = get_loc_range(loc_str)

            base_key = (book, start, end)
            seq = collision_counter.get(base_key, 0)
            collision_counter[base_key] = seq + 1
            key = (book, start, end, seq)

            merged[key] = {
                "Book Title": book,
                "Excerpt": entry.get('content', '').strip(),
                "Note": "",
                "Date Time": entry.get('date', ''),
                "Page": entry.get('page', ''),
                "Location": loc_str
            }
        elif entry['type'] == "Note":
            notes_pending.append(entry)

    for note in notes_pending:
        book = note.get('book', 'Unknown')
        loc_str = note.get('location', 'Unknown')

        note_val = None
        if loc_str and loc_str.isdigit():
            note_val = int(loc_str)
        elif '-' in loc_str:
            try:
                note_val = int(loc_str.split('-')[0])
            except ValueError:
                pass

        matched = False
        for key, data in merged.items():
            if key[0] == book and key[1] is not None and note_val is not None:
                if key[1] <= note_val <= key[2]:
                    data["Note"] = note.get('content', '').strip()
                    matched = True
                    break

        if not matched:
            start, end = get_loc_range(loc_str)
            key = (book, start, end, "NOTE_ONLY")
            merged[key] = {
                "Book Title": book,
                "Excerpt": "",
                "Note": note.get('content', '').strip(),
                "Date Time": note.get('date', ''),
                "Page": "",
                "Location": loc_str
            }

    return merged

def export_to_csv(merged_data, output_path):
    """
    Export merged data to a CSV file.
    """
    sorted_data = sorted(merged_data.values(), key=lambda x: (x["Book Title"], x["Location"]))
    fieldnames = ["Book Title", "Excerpt", "Note", "Date Time", "Page", "Location"]

    try:
        with open(output_path, 'w', newline='', encoding='utf-8-sig') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(sorted_data)
        return True
    except Exception as e:
        print(f"Failed to export CSV: {e}")
        return False

def main():
    """
    Main program flow: Clean -> Read -> Parse -> Merge -> Export
    Returns True for success, False for failure.
    """
    input_file = "My Clippings.txt"
    output_file = "My Clippings.csv"

    cleanup_output_file(output_file)

    print(f"Reading {input_file}...")
    lines = read_clippings_file(input_file)
    if not lines:
        return False

    print("Parsing data...")
    raw_entries = parse_clippings(lines)

    print("Performing association merge...")
    merged_data = merge_entries(raw_entries)

    print(f"Exporting to {output_file}...")
    if export_to_csv(merged_data, output_file):
        print("\nSuccess! File generated: My Clippings.csv")
        print(f"Processed {len(raw_entries)} raw records, merged into {len(merged_data)} unique records.")
        return True
    else:
        print("\nAn error occurred during export. Please check file permissions.")
        return False

if __name__ == "__main__":
    main()
