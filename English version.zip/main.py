import os
import ClipBackup
import KindleParser
import Convertor

def main():
    """
    Main program flow:
    1. User confirms Kindle connection  2. Backup files  3. Parse CSV  4. Convert XLSX  5. Clean up temp files
    """

    # 1. Program start prompt, wait for user to press Enter to continue
    print("\n=========================================================")
    print("Clippings2Sheet -- Kindle Clippings and Notes Conversion Tool Ver. 0.2")
    print("=========================================================\n\n")
    print("\nPlease connect your Kindle to the computer via USB cable, then press Enter to continue")
    input()

    try:
        # 2. Call the three program modules in sequence
        print("\n--- 1. Backing up Kindle clippings file ---")
        if not ClipBackup.main():
            print("\n[Notice] Backup module stopped, main program will terminate.")
            input("\nPress Enter to exit the program...")
            return

        print("\n--- 2. Parsing clipping data ---")
        if not KindleParser.main():
            print("\n[Notice] Parsing module encountered an error, main program will terminate.")
            input("\nPress Enter to exit the program...")
            return

        print("\n--- 3. Converting data to Excel spreadsheet file ---")
        if not Convertor.main():
            print("\n[Notice] Conversion error, main program will terminate.")
            input("\nPress Enter to exit the program...")
            return

        # 3. After execution, clean up the intermediate My Clippings.csv file
        csv_file = "My Clippings.csv"
        if os.path.exists(csv_file):
            try:
                os.remove(csv_file)
                print(f"\n[Cleanup] Deleted temporary file: {csv_file}")
            except Exception as e:
                print(f"\n[Warning] Failed to clean up temporary file {csv_file}: {e}")

        print("\n-----------------------------------------------------")
        print("All tasks completed! Please check the generated .xlsx file in the current directory.")
        print("-----------------------------------------------------")
        input("\nPress Enter to exit the program...")

    except Exception as e:
        # 4. If any module errors, display error message and wait for Enter to exit
        print("\n" + "!" * 50)
        print(f"Program error: {e}")
        print("Program error occurred, please press Enter to exit")
        print("!" * 50)
        input()

if __name__ == "__main__":
    main()
