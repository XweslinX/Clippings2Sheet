import csv
import openpyxl
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter
from datetime import datetime
from collections import defaultdict
import os

def get_safe_unique_title(title, existing_titles):
    """
    Generate a valid and unique Excel Sheet name.
    1. Replace illegal characters \ / * [ ] : ?
    2. Truncate to 31 characters
    3. Handle duplicate names by adding _1, _2 suffixes for uniqueness
    """
    safe_title = title
    for char in r'\/*[]:?':
        safe_title = safe_title.replace(char, ' ')

    safe_title = safe_title[:31].strip() or "Untitled Book"

    final_title = safe_title
    counter = 1
    while final_title in existing_titles:
        base_name = safe_title[:25]
        suffix = f"_{counter}"
        final_title = (base_name + suffix)[:31]
        counter += 1

    existing_titles.add(final_title)
    return final_title

def group_data_by_book(file_path):
    """
    Read the CSV file and group records by book title.
    """
    books_data = defaultdict(list)
    if not os.path.exists(file_path):
        print(f"Error: Input file not found {file_path}")
        return None

    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                book = row.get('Book Title', 'Unknown Book')
                books_data[book].append(row)
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return None

    return books_data

def sort_entries(entries):
    """
    Sort by the numeric value of the 'Location' column in ascending order.
    """
    def get_loc_val(entry):
        loc_str = entry.get('Location', '0')
        try:
            clean_loc = ''.join(filter(lambda x: x.isdigit() or x == '-', loc_str))
            if '-' in clean_loc:
                return int(clean_loc.split('-')[0])
            return int(clean_loc) if clean_loc else 0
        except ValueError:
            return 0

    return sorted(entries, key=get_loc_val)

def generate_filename():
    """
    Generate filename: Clippings-YYYYMMDDHHMMSS.xlsx
    """
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"Clippings-{timestamp}.xlsx"

def setup_sheet_layout(ws):
    """
    Set up headers, font styles, and column widths.
    """
    headers = ["Book Title", "Location", "Page", "Excerpt", "Note", "Date/Time"]
    widths = [30, 15, 10, 100, 50, 20]

    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num, value=header)
        cell.font = Font(size=14, bold=True)
        cell.alignment = Alignment(horizontal='center', vertical='center')

    for col_num, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(col_num)].width = width

def write_all_data_to_sheet(ws, entries):
    """
    Write all sorted data to the same worksheet, and set font size, auto-wrap, and dynamic row height.
    """
    sorted_entries = sort_all_data(entries) 

    for row_idx, entry in enumerate(sorted_entries, 2):
        row_data = [
            entry.get('Book Title', ''),
            entry.get('Location', ''),
            entry.get('Page', ''),
            entry.get('Excerpt', ''),
            entry.get('Note', ''),
            entry.get('Date/Time', '')
        ]

        for col_idx, value in enumerate(row_data, 1): # Cell alignment formatting
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = Font(size=12)
            if col_idx in [4, 5]:
                cell.alignment = Alignment(wrapText=True, vertical='top', horizontal='left')
            else:
                cell.alignment = Alignment(wrapText=True, horizontal='center', vertical='center')

        excerpt_text = entry.get('Excerpt', '')
        if excerpt_text:
            line_count = (len(excerpt_text) // 60) + 1
            calculated_height = 16 * line_count + 5
            ws.row_dimensions[row_idx].height = min(calculated_height, 300)
        else:
            ws.row_dimensions[row_idx].height = 16

def sort_all_data(entries):
    """
    Two-level sort: first by book title, then within the same book by location value in ascending order.
    """
    def get_loc_val(entry):
        loc_str = entry.get('Location', '0')
        try:
            clean_loc = ''.join(filter(lambda x: x.isdigit() or x == '-', loc_str))
            if '-' in clean_loc:
                return int(clean_loc.split('-')[0])
            return int(clean_loc) if clean_loc else 0
        except ValueError:
            return 0

    return sorted(entries, key=lambda x: (x.get('Book Title', ''), get_loc_val(x)))

def finalize_sheet(ws, total_rows):
    """
    Freeze the first row and enable auto-filter only on column A.
    """
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:A{total_rows + 1}"

def main():
    input_file = "My Clippings.csv"
    print(f"Reading {input_file}...")

    all_data = group_data_by_book(input_file) 
    all_entries = []
    if not os.path.exists(input_file):
        print(f"Error: Input file not found {input_file}")
        return False

    try:
        with open(input_file, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                all_entries.append(row)
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return False

    if not all_entries:
        print("No data could be read, program exiting.")
        return False

    wb = openpyxl.Workbook()
    ws = wb.active
    today_date = datetime.now().strftime("%Y%m%d")
    ws.title = today_date

    print(f"Generating worksheet {today_date} and setting format...")

    setup_sheet_layout(ws)
    write_all_data_to_sheet(ws, all_entries)
    finalize_sheet(ws, len(all_entries))

    output_file = generate_filename()
    try:
        wb.save(output_file)
        print(f"\nSuccess! File saved as: {output_file}")
        print(f"Total {len(all_entries)} records exported to a single worksheet.")
        return True
    except Exception as e:
        print(f"Error saving file: {e}")
        return False

if __name__ == "__main__":
    main()
