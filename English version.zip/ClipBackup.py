import ctypes
import os
import shutil

def find_kindle_disk():
    """
    Scan all drive letters on the computer, looking for a disk with volume label 'Kindle' and a 'documents' folder.
    """
    # Iterate through all possible drive letters A to Z
    for drive in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        drive_path = f"{drive}:\\"
        # Check if the drive exists (is mounted)
        if not os.path.exists(drive_path):
            continue

        try:
            # Create a buffer to store the volume label name
            vol_name_buffer = ctypes.create_unicode_buffer(1024)
            # Call Windows API GetVolumeInformationW to get disk details
            success = ctypes.windll.kernel32.GetVolumeInformationW(
                drive_path, vol_name_buffer, 1024, None, None, None, None, 0
            )
            if success and vol_name_buffer.value == "Kindle":
                # Further verify that the 'documents' folder exists in the drive root
                if os.path.isdir(os.path.join(drive_path, "documents")):
                    return drive_path # Return the found Kindle drive path (e.g. "G:\")
        except Exception:
            continue
    return None

def backup_clippings(disk_path):
    """
    Handle the backup logic for Kindle clippings files:
    Copy 'documents\My Clippings.txt' from the Kindle drive to the current program directory.
    """
    target_file = "My Clippings.txt"
    old_file = "My Clippings-old.txt"
    source_path = os.path.join(disk_path, "documents", target_file)

    try:
        # 1. Handle existing local files: if My Clippings.txt already exists in the current directory,
        #    rename it to My Clippings-old.txt (overwriting the old backup)
        if os.path.exists(target_file):
            os.replace(target_file, old_file)

        # 2. Copy the file from the Kindle device to the local directory
        #    Use shutil.copy2 to preserve original file metadata (e.g. modification time) as much as possible
        shutil.copy2(source_path, target_file)
        return True
    except (OSError, IOError) as e:
        # Catch I/O errors such as device disconnection, insufficient permissions, etc.
        print(f"\n[Error] Backup failed: {e}")
        return False

def prompt_connection():
    """
    Prompt the user to connect their Kindle device, and handle Y/N input logic.
    """
    while True:
        choice = input("\nPlease connect your Kindle to the computer via USB cable, then press Y to continue or N to exit: ").strip().upper()
        if choice == 'Y':
            return 'Y'
        elif choice == 'N':
            return 'N'
        else:
            # Handle unexpected input
            print("Invalid input. Please enter Y or N.")

def wait_for_exit():
    print("\nKindle notes exported successfully.\n")

def main():
    """
    Main control flow.
    Returns True if backup was executed successfully, False if the user chose to exit.
    """
    print("Detecting Kindle...")

    # Step 1: Connection check loop
    while True:
        disk = find_kindle_disk()
        if disk:
            break # Kindle detected successfully, exit the loop

        # Not detected, prompt the user
        if prompt_connection() == 'N':
            print("User chose to exit.")
            return False # Explicitly return False indicating the user requested to stop execution

    # Step 2: Execute file backup
    if backup_clippings(disk):
        # Backup successful
        # Note: when called as a module, no longer print wait_for_exit() message;
        # main.py handles unified output control
        return True
    else:
        # Backup failed, give a prompt and wait for Enter to exit
        print("\nAn error occurred during backup. Please check the device connection or file permissions.")
        input("Press Enter to exit...")
        return False
if __name__ == "__main__":
    main()
